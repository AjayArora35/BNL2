﻿
$(function () {


	$("#FruitsTable").DataTable({
		dom: 'Blfrtip',
		"processing": true,
		"serverSide": false,
		"filter": true,
		"scrollY": 500,
		"scrollX": true,
		"lengthMenu": [5, 10, 25, 50, 75, 100],
		"pageLength": 50,
		"bLengthChange": true,
		"ajax": {
			"url": toolkit.host + "Fruit/GetFruits",
			"type": "GET",
			"datatype": "json"
		},
		"columnDefs": [{
			"targets": [0],
			"visible": true,
			"searchable": true
		}],
		"columns": [
			//{ "data": "id", "name": "Id", "autoWidth": true },
			{ "data": "name", "name": "Name", "autoWidth": true },
			{ "data": "weight", "name": "Weight", "autoWidth": true },
			{ "data": "color", "name": "Color", "autoWidth": true },
			{ "data": "price", "name": "Price", "autoWidth": true },
			{
				"data": "datePicked", "name": "Picked Date", "autoWidth": true, render: function (d) {
					return (d) ? moment(d).format("YYYY-MM-DD") : d;
				}
},
			{ "data": "hasSeeds", "name": "Seeds?", "autoWidth": true },
			{ "data": "type", "name": "Type", "autoWidth": true },
		]
	});

	$("#FruitsTable_length").hide();

	$('#fruitdate').on('change', function () {
		let chosenDate = $("#fruitdate").val();

		(chosenDate !== "") ? $("#FruitsTable_length").show() : $("#FruitsTable_length").hide();
			
	})

	

});