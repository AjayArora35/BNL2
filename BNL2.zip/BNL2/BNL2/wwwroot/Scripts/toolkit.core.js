﻿
let toolkit = {};

//toolkit.host = window.location.protocol + "//" + window.location.host + "/Web";
toolkit.host = window.location.protocol + "//" + window.location.host + "/";

let d = new Date();

let month = d.getMonth() + 1;
let day = d.getDate();

let getTodayDate = d.getFullYear() + '/' +
    (('' + month).length < 2 ? '0' : '') + month + '/' +
    (('' + day).length < 2 ? '0' : '') + day;


