﻿using BNL2.Web.Storage.Models.Fruits;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace BNL2.Web.ViewModels
{
    public class FruitModel
    {
        public string? Name { get; set; }
        public double Weight { get; set; }
        public string? Color { get; set; }
        public decimal? Price { get; set; }
        public DateTime? DatePicked { get; set; }
        public bool HasSeeds { get; set; } = false;

        public string? Type { get;set ; }

    }

    public class FruitEntries
    {
        public IList<FruitModel> Entries { get; set; }

        public FruitEntries() { 
            Entries = new List<FruitModel>();
        }
    }
}
