using BNL2.Storage.Models;
using BNL2.Web.Storage.Models.Fruits;
using BNL2.Web.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using static Apollo.Web.Helpers.Enums;

namespace BNL2.Controllers
{
    public class FruitController : Controller
    {
        private readonly ILogger<FruitController> _logger;

        public FruitController(ILogger<FruitController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [Route("~/Fruit/GetFruits"), HttpGet]

        public JsonResult GetFruits() 
        {
            // Send a collection of fruit to UI

            (int recordsTotal, FruitEntries viewModel) = ConstructFruitList();

            return Json(new {data = viewModel.Entries, recordsFiltered = recordsTotal, error = string.Empty});
        }

        private (int, FruitEntries) ConstructFruitList()
        {
            List<Fruit> fruitCollection = new List<Fruit>();
            // Get all specific fruits 
            var fruits = Enum.GetNames(typeof(SpecificFruits));

            // Loop through the fruits and instantiate new fruit and add to collection
            for (int i = 0; i <= 1; i++)
            {
                foreach (var fruit in fruits)
                {
                    switch (fruit)
                    {
                        case "Apple":
                            fruitCollection.Add(new Apple("Apple", 0.5, "Red", i + 1, DateTime.Now, true));
                            break;
                        case "Banana":
                            fruitCollection.Add(new Banana("Banana", 0.5, "Yellow", i + 1, DateTime.Now, false));
                            break;
                        case "Cherry":
                            fruitCollection.Add(new Cherry("Cherry", 0.01, "Red", i + 1, DateTime.Now, false));
                            break;
                        case "Coconut":
                            fruitCollection.Add(new Coconut("Coconut", 1.01, "Brown", i + 1, DateTime.Now, false));
                            break;
                        case "Strawberry":
                            fruitCollection.Add(new Strawberry("Strawberry", 0.02, "Red", i + 1, DateTime.Now, true));
                            break;
                        case "Kiwi":
                            fruitCollection.Add(new Kiwi("Kiwi", 0.1, "Green", i + 1, DateTime.Now, true));
                            break;
                    }
                }
            }

            FruitEntries viewModel = new FruitEntries();
            // Populate view model for UI
            foreach (var fruit in fruitCollection)
            {
                fruit.MakeEdible(); //Currently writes to console -- Future -- change behavior of method

                FruitModel fm = new();
                fm.Name = fruit.Name;
                fm.Weight = fruit.Weight;
                fm.Price = fruit.Price;
                fm.DatePicked = fruit.DatePicked;
                fm.HasSeeds = fruit.HasSeeds;
                fm.Color = fruit.Color;
                fm.Type = fruit.Taxonomy();
                viewModel.Entries.Add(fm);
            }

            int recordsTotal = fruitCollection.Count();

            return (recordsTotal, viewModel);
        }
    }
}
