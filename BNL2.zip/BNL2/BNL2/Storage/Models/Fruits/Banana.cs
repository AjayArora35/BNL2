﻿namespace BNL2.Web.Storage.Models.Fruits
{
    public class Banana : Fruit
    {
        public Banana(string name, double weight, string color, decimal price, DateTime datePicked, bool hasSeeds) : base(name, weight, color, price, datePicked, hasSeeds)
        {
            
        }

        public override void MakeEdible()
        {
            Console.WriteLine("I am a Banana");
        }
        public override string Taxonomy()
        {
            return "Fleshy fruit";
        }

    }
}
