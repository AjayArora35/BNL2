﻿namespace BNL2.Web.Storage.Models.Fruits
{
    public abstract class Fruit
    {
        private string _Name { get; set; }
        private double _Weight { get; set; }
        private string _Color { get; set; }
        private decimal _Price { get; set; }
        private DateTime _DatePicked { get; set; }
        private bool _HasSeeds { get; set; }

        // Constructor
        public Fruit(string name, double weight, string color, decimal price, DateTime datePicked, bool hasSeeds)
        {
            _Name = name;
            _Weight = weight;
            _Color = color;
            _Price = price;
            _DatePicked = datePicked;
            _HasSeeds = hasSeeds;
        }

        // Getters
        public string Name
        {
            get { return _Name; }
        }

        public double Weight
        {
            get { return _Weight; }
        }

        public string Color
        {
            get { return _Color; }
        }

        public decimal Price
        {
            get { return _Price; }
        }

        public DateTime DatePicked
        {
            get { return _DatePicked; }
        }

        public bool HasSeeds
        {
            get { return _HasSeeds; }
        }
        // Method to make the fruit edible (implementation can be defined in derived classes)
        public abstract void MakeEdible();

        public abstract string Taxonomy();

    }


}
