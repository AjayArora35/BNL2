﻿namespace BNL2.Web.Storage.Models.Fruits
{
    public class Apple : Fruit
    {
        public Apple(string name, double weight, string color, decimal price, DateTime datePicked, bool hasSeeds) : base(name, weight, color, price, datePicked, hasSeeds)
        {

        }

        public override void MakeEdible()
        {
            Console.WriteLine("I am a Apple");
        }

        public override string Taxonomy()
        {
            return "Simple fruit";
        }
    }
}
