﻿namespace BNL2.Web.Storage.Models.Fruits
{
    public class Strawberry: Fruit
    {
        public Strawberry(string name, double weight, string color, decimal price, DateTime datePicked, bool hasSeeds) : base(name, weight, color, price, datePicked, hasSeeds)
        {

        }

        public override void MakeEdible()
        {
            Console.WriteLine("I am a Strawberry");
        }

        public override string Taxonomy()
        {
            return "Aggregate fruit";
        }

    }
}
