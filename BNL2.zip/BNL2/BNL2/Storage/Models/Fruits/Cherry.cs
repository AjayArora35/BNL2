﻿namespace BNL2.Web.Storage.Models.Fruits
{
    public class Cherry : Fruit
    {
        public Cherry(string name, double weight, string color, decimal price, DateTime datePicked, bool hasSeeds) : base(name, weight, color, price, datePicked, hasSeeds)
        {

        }

        public override void MakeEdible()
        {
            Console.WriteLine("I am a Cherry");
        }
        public override string Taxonomy()
        {
            return "Fleshy fruit";
        }

    }
}
