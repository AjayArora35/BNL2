﻿using System.ComponentModel;

namespace Apollo.Web.Helpers
{
    public class Enums
    {
        public enum SpecificFruits
        {
            [Description("Apple")]
            Apple = 1,
            [Description("Banana")]
            Banana = 2,
            [Description("Cherry")]
            Cherry = 3,
            [Description("Coconut")]
            Coconut = 4,
            [Description("Kiwi")]
            Kiwi = 5,
            [Description("Strawberry")]
            Strawberry = 6,
        }
    }
}
